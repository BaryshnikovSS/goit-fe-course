const list = [
  { name: "Andrusha Evgenii" },
  { name: "Gildeeva Viktoria", photo: "/./image/Group/gildeeva.viktoria.jpg" },
  { name: "Iakovyna Grisha", photo: "/./image/Group/iakovyna.grisha.jpg" },
  { name: "Kosytsia Yaroslav", photo: "/./image/Group/kosytsia.yaroslav.jpg" },
  { name: "Medolyz Oleksandr", photo: "/./image/Group/Medolyz Oleksandr.JPG" },
  { name: "Roman Gnatyuk", photo: "/./image/Group/roman.gnatyuk.jpg" },
  { name: "Spon Anna", photo: "/./image/Group/sapon.anna.jpg" },
  {
    name: "Serhii Baryshnikov",
    photo: "/./image/Group/serhii.baryshnikov.jpg"
  },
  { name: "Vasyl Manyo", photo: "/./image/Group/vasyl.manyo.jpg" },
  { name: "Zelinsky Sergiy", photo: "/./image/Group/zelinsky.sergiy.jpg" },
  { name: "Maksim Lymar" },
  { name: "Misha Gorban" },
  { name: "Tania Shevtsova" },
  { name: "Svitelskiy Roman" },
  { name: "Aleksandr Lis" }
];

class BootCamp {
  constructor(
    _groupArr,
    subGroupCall = 4,
    container = BootCamp.DEFAULT_CONTAINER_SELECTOR
  ) {
    this.container = document.querySelector(container);
    this.sourceList = this.container.querySelector(
      BootCamp.DEFAULT_UL_SELECTOR
    );
    this.resultList = this.container.querySelector(
      BootCamp.DEFAULT_UL_RESAULT_SELECTOR
    );
    this.btn = this.container.querySelector(BootCamp.DEFAULT_BTN);
    this.copyOfArray = [].concat(_groupArr);
    this.orinCopy = [].concat(this.copyOfArray);
    this.groupArr = this.shuffledArr(this.copyOfArray);
    this.subGroupCall = subGroupCall;
    this.groups = [];
    this.quantityGroup = Math.ceil(this.groupArr.length / this.subGroupCall);
    this.createGroup();
    this.liAdd(this.orinCopy);
    this.btn.addEventListener("click", this.result.bind(this));
  }
  static DEFAULT_CONTAINER_SELECTOR = "#js-container";
  static DEFAULT_UL_SELECTOR = ".js-group_list";
  static DEFAULT_UL_RESAULT_SELECTOR = ".js-newgroup_list";
  static DEFAULT_BTN = ".js-btn";
  shuffledArr(arr) {
    const newGroup = arr.sort(() => Math.random() - 0.5);
    return newGroup;
  }
  createGroup() {
    this.groups = [];
    for (let i = 0; i < this.subGroupCall; i++) {
      this.groups.push(this.groupArr.splice(0, this.quantityGroup));
    }
  }
  resultAdd(arr) {
    const resultItem = arr.reduce((acc, element) => {
      return (acc += `<li class="result_item"><img class="group_img" src="${
        element.photo ? element.photo : "./image/Group/defoult.jpg"
      }" alt="${element.name}"> <span>${element.name}</span></li>`);
    }, "");

    this.resultList.insertAdjacentHTML(
      "afterbegin",
      resultItem + '<hr class="group_line">'
    );
  }
  liAdd(arr) {
    const groupItem = arr.reduce((acc, element) => {
      return (acc += `<li class="group_item"><img class="group_img" src="${
        element.photo ? element.photo : "./image/Group/defoult.jpg"
      }" alt="${element.name}"> <span>${element.name}</span></li>`);
    }, "");

    this.sourceList.insertAdjacentHTML("afterbegin", groupItem);
  }
  result() {
    this.resultList.innerHTML = "";
    this.groupArr = this.shuffledArr([].concat(this.orinCopy));
    this.createGroup();
    this.groups.forEach(value => {
      this.resultAdd(value);
    });
  }
}
const g17 = new BootCamp(list);
